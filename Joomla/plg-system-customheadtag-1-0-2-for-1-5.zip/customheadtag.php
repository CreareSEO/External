<?php
/**
 * @package Custom Head Tag System for Joomla!1.5
 * @version 1.0.2
 * @copyright Copyright (C) 2008 Joomler!.net. All rights reserved.
 * @access joomlers@gmail.com
 * @link http://www.joomler.net/
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 *
 * change log
 * update 1.0.2
 * add Custom tag
 *
 * update 1.0.1
 * fix : Two or more scripts and style
 *
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.event.plugin');

class  plgSystemCustomHeadTag extends JPlugin
{

	function plgSystemCustomHeadTag( &$subject, $config )
	{
		parent::__construct($subject, $config);
	}

	function onAfterDispatch()
	{
		$uri = JRequest::getURI();
		if(strpos('J'. $uri, 'administrator/')){
			return;
		}
		$plugin =& JPluginHelper::getPlugin('system', 'customheadtag');
 		$params = new JParameter( $plugin->params );
		$menu		= $this->Jlr_ArrayToInteger(explode(',', trim($params->get('menu'))));
		$content	= $this->Jlr_ArrayToInteger(explode(',', trim($params->get('content'))));
		$display	= intval($params->get('display'));
		$scripturl	= trim($params->get('scripturl'));
		$script		= trim($params->get('script'));
		$styleurl	= trim($params->get('styleurl'));
		$style		= trim($params->get('style'));
		$headtag	= trim($params->get('headtag'));

 		if(empty($scripturl) && empty($script) && empty($styleurl) && empty($style) && empty($headtag)){
			return;
		}

		$Itemid = (int)JRequest::getVar('Itemid', 0);
		switch($display){
			case 0://menu
				if(empty($menu)){
					return;
				}
				if(!in_array($Itemid, $menu)){
					return;
				}
				break;
			case 1://both
				if(empty($menu) && empty($content)){
					return;
				}
				if(!empty($menu) && in_array($Itemid, $menu)){
					break;
				}
				if(!empty($content) && in_array($this->Jlr_getArticleID(), $content)){
					break;
				}
				return;
			case 2://content
				if(empty($content)){
					return;
				}
				if(in_array($this->Jlr_getArticleID(), $content)){
					break;
				}
				return;
			default://all
				break;
		}
		$doc = &JFactory::getDocument();
		if(!empty($headtag)){
			$GLOBALS['mainframe']->addCustomHeadTag($headtag);
		}
 		if(!empty($scripturl)){
 			$this->Jlr_addTags($doc, $scripturl);
 		}
 		if(!empty($script)){
 			$doc->addScriptDeclaration($script);
 		}
 		if(!empty($styleurl)){
 			$this->Jlr_addTags($doc, $styleurl, 0);
 		}
 		if(!empty($style)){
 			$doc->addStyleDeclaration($style);
 		}
 		return;

	}

	function Jlr_addTags(&$doc, $str, $type=1)
	{
		$lines = explode("\n", $str);
		foreach($lines as $line){
			$temp = trim($line);
			if(empty($temp)){
				continue;
			}
			if($type){
				$doc->addScript($this->Jlr_getURL($temp));
			} else {
				$doc->addStyleSheet($this->Jlr_getURL($temp));
			}
		}
	}

	function Jlr_getURL($path)
	{
		$root = JURI::base();
		if(strpos($path, 'http') === 0){
			return $path;
		} else if(strpos($path, '/') === 0){
			return  $root. substr($path, 1);
		} else {
			return $root. $path;
		}
	}

	function Jlr_getArticleID()
	{
		if(JRequest::getVar('option') == 'com_content'){
			return (int)JRequest::getVar('id', 0, '', 'int');
		}
		return;
	}

	function Jlr_ArrayToInteger($array, $zero=false)
	{
		$return = array();
		if(is_array($array)){
			foreach($array as $i => $v){
				$value = (int)$v;
				if($zero){
					$return[$i] = $value;
				} else if($value){
					$return[$i] = $value;
				}
			}
		} else {
			if((int)$array || $zero){
				$return = array((int)$array);
			}
		}
		return $return;
	}
}
?>